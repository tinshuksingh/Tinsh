package com.tinsh.controller;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.permission.FsAction;
import org.apache.hadoop.fs.permission.FsPermission;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class MainClass {

    public static void main(String[] arguments) {
    	
	        //ApplicationContext ctx = new ClassPathXmlApplicationContext("hadoop-context.xml");
	        
	        Configuration config = new Configuration();
	        config.set("fs.defaultFS","hdfs://localhost:8020");

	        FileSystem dfs;
			try {
				dfs = FileSystem.get(config);
				String dirName = "TestDirectory/Test/";
				Path src = new Path("/home/admin/Desktop/tinsh/"+dirName);
				dfs.mkdirs(src);
				//dfs.setPermission(src,new FsPermission(FsAction.ALL,FsAction.ALL,FsAction.ALL));
				dfs.setOwner(src, "admin", "admin");
				//dfs.delete(src);
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    }
}

