package com.tinsh.sampleFreemarker;

import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class WelcomeController {

	@Value("${application.message:Hello World}")
	private String message = "Hello World";

	/*@GetMapping("/")
	public String welcome(Map<String, Object> model) {
		model.put("time", new Date());
		model.put("message", this.message);
		return "welcome";
	}*/
	
	@RequestMapping("/")
	protected ModelAndView getHome(HttpServletRequest request,
			HttpServletResponse response , ModelAndView model ){

		System.out.println("In the home page.");
		model.addObject("time", new Date());
		model.addObject("message",this.message);
		model.setViewName("welcome");
		return model;
		
	}
	
	@RequestMapping("/form")
	protected ModelAndView getForm(HttpServletRequest request,
			HttpServletResponse response , ModelAndView model ){

		System.out.println("In the form page.");
		/*model.addObject("time", new Date());
		model.addObject("message",this.message);*/
		model.setViewName("form");
		return model;
		
	}

	
}
