package com.discover.datahubrest.common;

import java.io.File;
import java.io.IOException;

import javax.naming.NamingException;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import com.discover.datahubrest.common.config.AppConfig;
import com.discover.datahubrest.common.config.EnvironmentConfig;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CommonConfigReader {

	private static String DFS_ENV = "java:comp/env/DFSEnvironment";

	public static void configure(String appConfigFile, String log4jConfigFile) {
		AppConfig appConfig = null;
		try {
			appConfig = new ObjectMapper().readValue(new File(appConfigFile), AppConfig.class);
			String serverEnvironment = null;

			serverEnvironment = (String) new javax.naming.InitialContext().lookup(DFS_ENV);

			if (serverEnvironment == null) {
				System.out.println("serverEnvironment is null");
				serverEnvironment = "PA";
			}

			for (EnvironmentConfig env : appConfig.getEnvironments()) {
				if (env.getEnvName().equals(serverEnvironment)) {
					System.out.println(env);
					configureLog4j(log4jConfigFile, env.getLogLevel());
					break;
				}
			}
		} catch (IOException e) {
			System.out.println("Unable to read app specific config. Using default app config");
			e.printStackTrace();
		} catch (NamingException e) {
			System.out.println("Unable to find DFS Environment");
			e.printStackTrace();
		}
	}

	private static void configureLog4j(String log4jConfigFile, String logLevel) {
		if (log4jConfigFile == null) {
			System.out.println("log4jConfigFile is null. Loading basic log4j configuration");
			BasicConfigurator.configure();
		} else {
			DOMConfigurator.configureAndWatch(log4jConfigFile);
			switch (logLevel) {
			case "DEBUG":
				Logger.getRootLogger().setLevel(Level.DEBUG);
				break;
			case "INFO":
				Logger.getRootLogger().setLevel(Level.INFO);
				break;
			case "WARN":
				Logger.getRootLogger().setLevel(Level.WARN);
				break;
			case "ERROR":
				Logger.getRootLogger().setLevel(Level.ERROR);
				break;
			case "FATAL":
				Logger.getRootLogger().setLevel(Level.FATAL);
				break;
			default:
				Logger.getRootLogger().setLevel(Level.INFO);
			}
		}

	}

}
