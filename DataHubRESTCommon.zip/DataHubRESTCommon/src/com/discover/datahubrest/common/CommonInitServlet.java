package com.discover.datahubrest.common;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;

public class CommonInitServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void init() {
		ServletContext ctx = getServletContext();
		String appConfig = getInitParameter("appConfigFile");
		String appConfigPath = ctx.getRealPath(appConfig);
		String log4jConfig = getInitParameter("log4jConfigLocation");
		String log4jConfigPath = ctx.getRealPath(log4jConfig);

		CommonConfigReader.configure(appConfigPath, log4jConfigPath);
	}

}
