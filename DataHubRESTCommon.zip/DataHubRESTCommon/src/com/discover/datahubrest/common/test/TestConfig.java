package com.discover.datahubrest.common.test;

import java.io.File;
import java.io.IOException;

import com.discover.datahubrest.common.config.AppConfig;
import com.discover.datahubrest.common.config.EnvironmentConfig;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestConfig {

	private static String appConfigFile = "/WEB-INF/resources/appConfig.json";

	public static void main(String[] args) {

		AppConfig appConfig = null;
		ObjectMapper mapper = new ObjectMapper();
		try {
			appConfig = mapper.readValue(new File(appConfigFile), AppConfig.class);
			System.out.println(appConfig);
		} catch (IOException e) {
			System.err.println("enable to read app specific config");
			e.printStackTrace();
		}
		try {
			System.out.println("reading default app config");
			appConfig = mapper.readValue(new File("/home/admin/appConfig.json"), AppConfig.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println(appConfig);

		for (EnvironmentConfig env : appConfig.getEnvironments()) {
			if (env.getEnvName().equals("PA"))
				System.out.println(env);
		}

	}

}
