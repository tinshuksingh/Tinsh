package com.discover.datahubrest.common.config;

public class EnvironmentConfig {

	private String envName;
	private String logLevel;

	public String getEnvName() {
		return envName;
	}

	public void setEnvName(String envName) {
		this.envName = envName;
	}

	public String getLogLevel() {
		return logLevel;
	}

	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}

	@Override
	public String toString() {
		return "EnvironmentConfig [envName=" + envName + ", logLevel=" + logLevel + "]";
	}
	
	

}
