package com.discover.datahubrest.common.config;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AppConfig {

	@JsonProperty("applicationName")
	private String applicationName;
	@JsonProperty("environments")
	private List<EnvironmentConfig> environments;

	public String getAppName() {
		return applicationName;
	}

	public void setAppName(String appName) {
		this.applicationName = appName;
	}

	public List<EnvironmentConfig> getEnvironments() {
		return environments;
	}

	public void setEnvironments(List<EnvironmentConfig> environments) {
		this.environments = environments;
	}

	@Override
	public String toString() {
		return "AppConfig [applicationName=" + applicationName + ", environments=" + environments + "]";
	}
	
	

}
