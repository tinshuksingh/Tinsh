package com.tinsh.rabbitmq.test;

import org.junit.Test;

import com.tinsh.rabbitmq.common.MessageSenderHelper;
import com.tinsh.rabbitmq.common.RabbitMQException;

public class RabbitMQTest {
	
	

	 @Test(expected = RabbitMQException.class)
    public void shouldReturnMessageSenderHelperClassInstance() {
		 
		 MessageSenderHelper.initMQContext(null);
    }

    /*@Test
    public void test_method_2() {
        System.out.println("@Test - test_method_2");
    }*/

}
