package com.tinsh.rabbitmq.common;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MessageListenerHelper {

	private static AbstractApplicationContext ctx=null;
	
	public static void initListenerContext(){
			
		try {
			System.setProperty("MQ_CONFIG_FILE", "common-mq-configuration.properties");
			
			if(ctx == null){
				ctx=new ClassPathXmlApplicationContext("com/tinsh/rabbitmq/common/mq-listener-context.xml");
				System.out.println("Listener context is Initialized with default properties.");
			}
		} catch (Exception e) {
			throw new RabbitMQException();
		}
		
		}
	
	public static void initListenerContext(String mqConfiFile){
		try{
			if(ctx != null){
				System.setProperty("MQ_CONFIG_FILE", mqConfiFile);
				AbstractApplicationContext ctx=new ClassPathXmlApplicationContext("com/tinsh/rabbitmq/common/mq-listener-context.xml");
				System.out.println("Listener context is Initialized.");
			}
		}catch(Exception e){
			throw new RabbitMQException();
		}
	}
	
	public void listen(String msg) {
			System.out.println("Listen method called.");
			System.out.println(msg);
	}

}
