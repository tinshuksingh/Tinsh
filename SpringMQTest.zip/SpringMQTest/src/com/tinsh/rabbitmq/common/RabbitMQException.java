package com.tinsh.rabbitmq.common;

public class RabbitMQException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8017280038002919905L;
	
	public void RabbitMQException(){
		
	}

}
