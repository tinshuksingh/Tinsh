package com.tinsh.rabbitmq.common;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MessageSenderHelper {

	private static AbstractApplicationContext ctx =null;
	private static RabbitTemplate template=null;
	
	public static void initMQContext() {
		try{
			System.setProperty("MQ_CONFIG_FILE", "common-mq-configuration.properties");
			if(ctx == null){
				ctx =new ClassPathXmlApplicationContext("com/tinsh/rabbitmq/common/mq-sender-context.xml");
				template = ctx.getBean(RabbitTemplate.class);
				System.out.println("MQ Context initialized with default MQ properties.");
			}
		}catch(Exception e){
			throw new RabbitMQException();
		}
		
	}
	
	public static void initMQContext(String mqConfigFile){
		
		if(mqConfigFile != null && mqConfigFile.trim().equals("")){
			throw new RabbitMQException();
		}
		
		try{
			System.setProperty("MQ_CONFIG_FILE", mqConfigFile);
			if(ctx == null){
				ctx =new ClassPathXmlApplicationContext("com/tinsh/rabbitmq/common/mq-sender-context.xml");
				template = ctx.getBean(RabbitTemplate.class);
				System.out.println("MQ Sender Context initialized.");
			}
		}catch(Exception e){
			e.printStackTrace();
			throw new RabbitMQException();
		}
		
	}
	
	public static RabbitTemplate getRabbitTemplate(){
		
		try {
			if(ctx==null){
				System.out.println("<MQSender context is not initialized.>");
				initMQContext();
			}
			template = ctx.getBean(RabbitTemplate.class);
		} catch (Exception e) {
			throw new RabbitMQException();
		}
		return template;
	}
	
	public void destroyContext(){
		ctx.destroy();
		System.out.println("MQSender Context is destoryed.");
	}

}
