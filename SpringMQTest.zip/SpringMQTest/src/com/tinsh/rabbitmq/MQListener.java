package com.tinsh.rabbitmq;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MQListener {

	public void listen(String msg) {
		
		System.out.println("Listen method called.");
		System.out.println(msg);
	}
	
	public static void main(String[] args) throws InterruptedException {
			AbstractApplicationContext ctx=new ClassPathXmlApplicationContext("mq-listener-context.xml");
			Thread.sleep(1000);
			ctx.destroy();
	}
}
