package com.tinsh.rabbitmq;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class RabbitMQServlet extends HttpServlet{


	  private String message;

	  /*public void init() throws ServletException
	  {
	      message = "Hello Tinshuk!";
	      MQInitializer mqInit=new MQInitializer();
	     // mqInit.initMQSender();
	      try {
			//mqInit.readMessage();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }*/

	  public void doGet(HttpServletRequest request,
	                    HttpServletResponse response)
	            throws ServletException, IOException
	  {
	      // Set response content type
	      response.setContentType("text/html");

	      // Actual logic goes here.
	      PrintWriter out = response.getWriter();
	      out.println("<h1>" + message + "</h1>");
	  }
	
}
