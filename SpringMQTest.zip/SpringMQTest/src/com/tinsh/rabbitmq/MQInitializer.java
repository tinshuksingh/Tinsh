package com.tinsh.rabbitmq;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tinsh.rabbitmq.common.MessageListenerHelper;
import com.tinsh.rabbitmq.common.MessageSenderHelper;

public class MQInitializer extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2083054739666795653L;

	private void initMQSender() {
		MessageSenderHelper.initMQContext("common-mq-configuration.properties");
	}
	
	private void readMessage() {
			MessageListenerHelper.initListenerContext();
	}
	
	public void init() throws ServletException {
		MQInitializer mqInit=new MQInitializer();
		mqInit.initMQSender();
		mqInit.readMessage();
	  }
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
	}
}
