package com.tinsh.rabbitmq;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MQSender {

	public static void main(String[] args) throws InterruptedException {

		AbstractApplicationContext ctx =new ClassPathXmlApplicationContext("mq-sender-context.xml");
			RabbitTemplate template = ctx.getBean(RabbitTemplate.class);
			template.convertAndSend("Hello, tinsh2!");
			System.out.println("message sent successfully.");
			Thread.sleep(1000);
			ctx.destroy();
		}
	}
