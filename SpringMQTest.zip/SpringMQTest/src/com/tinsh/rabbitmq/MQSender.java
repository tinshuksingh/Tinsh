package com.tinsh.rabbitmq;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.amqp.rabbit.core.RabbitTemplate;

import com.tinsh.rabbitmq.common.MessageSenderHelper;

public class MQSender extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3829234475888976501L;

	public static void main(String[] args) throws InterruptedException, IOException {
			sendMessage();
	}
	
	public static void sendMessage() throws IOException{
			RabbitTemplate template=MessageSenderHelper.getRabbitTemplate();
			template.convertAndSend("Tinshuk Singh.");
			System.out.println("message sent successfully.");
		}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			sendMessage();
		}
	}
