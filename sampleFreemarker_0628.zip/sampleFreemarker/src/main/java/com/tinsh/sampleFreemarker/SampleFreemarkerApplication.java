package com.tinsh.sampleFreemarker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleFreemarkerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleFreemarkerApplication.class, args);
	}
}
