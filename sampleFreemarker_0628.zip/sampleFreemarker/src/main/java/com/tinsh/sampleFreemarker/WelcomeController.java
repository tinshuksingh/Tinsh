package com.tinsh.sampleFreemarker;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class WelcomeController {

	Logger logger= Logger.getLogger(this.getClass());
	
	@RequestMapping("/")
	protected ModelAndView getHome(HttpServletRequest request,
			HttpServletResponse response , ModelAndView model){
		System.out.println("In the home page");
		logger.debug("In the home page");
		model.addObject("home",false);
		model.setViewName("home");
		return model;
	}
	
	@RequestMapping(path="/login" ,method=RequestMethod.POST)
	protected ResponseEntity<User> login(@RequestBody User user, ModelAndView model) throws Exception{
		System.out.println("In the login page.");
		System.out.println("userName :"+user.getUserName());
		System.out.println("password :"+user.getPassword());
		ResponseEntity<User> response;
		if(isUserValid(user.getUserName(),user.getPassword())){
			System.out.println("user is authenticated.");
			model.addObject("home",true);
			model.addObject("userName", user.getUserName());
			model.setViewName("home");
			response= new ResponseEntity<>(user,HttpStatus.OK);  
		}else{
			response= new ResponseEntity<>(user,HttpStatus.INTERNAL_SERVER_ERROR);  
		}
		return response;
	}
	
	
	@RequestMapping(path="/home" ,method=RequestMethod.GET)
	protected ModelAndView getWelcomePage(ModelAndView model, String userName) throws Exception{
		System.out.println("In the home page.");
		
		model.addObject("home",true);
		model.addObject("name",userName);
		model.setViewName("home");
		return model;
	}
	
	@RequestMapping(path="/home" ,method=RequestMethod.POST)
	protected ModelAndView getWelcomePage(ModelAndView model, @RequestBody User user) throws Exception{
		System.out.println("In the home page.");
		
		model.addObject("home",true);
		model.addObject("name",user.getUserName());
		model.setViewName("home");
		return model;
	}
	
	public static Connection getConnection() throws Exception {
		 Connection conn=DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Datahub\\Desktop\\Tinsh\\Project\\DB\\GrabBreakfast_DB.accdb");
		 return conn;
	 }
	 
	 public static void getData() throws Exception {
		    Connection conn = null;
		    Statement stmt = null;
		    ResultSet rs = null;

		    conn = getConnection();
		    stmt = conn.createStatement();
		    String excelQuery = "select username,password from login";
		    rs = stmt.executeQuery(excelQuery);

		    while (rs.next()) {
		    	System.out.println("username :"+rs.getString("username"));
		    }

		    rs.close();
		    stmt.close();
		    conn.close();
		  }
	 
	 private static boolean isUserValid(String userName,String password) throws Exception{
		 	Connection conn = null;
		    Statement stmt = null;
		    ResultSet rs = null;

		    conn = getConnection();
		    stmt = conn.createStatement();
		    String excelQuery = "select username,password from login";
		    rs = stmt.executeQuery(excelQuery);

		    while (rs.next()) {
		    	System.out.println("username :"+rs.getString("username"));
		    	if(rs.getString("username").equals(userName) && rs.getString("password").equals(password)){
		    		rs.close();
		  		    stmt.close();
		  		    conn.close();
		    		return true;
		    	}
		    }
		 return false;
	 }
	
}
