import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

    login: boolean=false;

   ngOnInit(){
    this.login=true;
    console.log("inside FooterComponent ngOnInit");
  }

}
