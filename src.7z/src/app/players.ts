
import { Player } from './player';
export const PLAYERS: Player[] = [
    { id: 11, name: 'MS Dhoni' },
    { id: 12, name: 'Virat Kohli' },
    { id: 13, name: 'Ravindra Jadeja' },
    { id: 14, name: 'Virendra Sehwag' },
    { id: 15, name: 'Yuvraj Singh' },
    { id: 16, name: 'Harbhajan' },
    { id: 17, name: 'Piyush Chawla' },
    { id: 18, name: 'Ravichandran Ashwin' },
    { id: 19, name: 'Inshant Sharma' },
    { id: 20, name: 'Rohit Sharma' }
  ];