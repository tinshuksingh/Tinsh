import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { LocalStorage } from './local-storage';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private _localStorage: LocalStorage, private router: Router) {

  }
  canActivate() {
    let token = this._localStorage.getAuthToken("AUTH_TOKEN");
    if (token == "undefined" || token == null) {
      this.router.navigate(['/login']);
      return false;
    }
    else {
    return true;
    }
  }
}
