import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { ActivatedRoute } from '@angular/router';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {LocalStorage} from '../local-storage'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  loginform1 : FormGroup;

  constructor(private fromBuilder : FormBuilder,
    private loginService : LoginService,private route: ActivatedRoute,
    private _router : Router,
    private localStorage : LocalStorage) {

      this.loginform1 = this.fromBuilder.group({'email' : ['', [Validators.required, Validators.email]],
      'password' : ['', [Validators.required, ]] });
      console.log("constructor");
     }


  ngOnInit() {
    this.localStorage.deleteAuthToken("AUTH_TOKEN");
  }


  token : String;
  submit(body : any): void {
    console.log("inside submit")
      this.loginService.loginCall(body).subscribe(
        resp => {this.token = resp.token;
        console.log("token :"+this.token);

        this.localStorage.setAuthToken("AUTH_TOKEN",this.token);
        this._router.navigateByUrl('dashboard');
        },
        error => {
          console.log(error);
          alert(error._body);
        })
 
     }

}
