import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Http, RequestOptions, Headers } from '@angular/http';
import {  map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private _client : Http) { }

  loginCall(data : any) : Observable<any>{
      let url = 'https://reqres.in/api/login';
      let body = JSON.stringify(data);
      var header = new Headers();
        header.append('Access-Control-Allow-Origin', '*');
        header.append("Content-Type", "application/json");
        header.append("accept", "application/json");
  
        let options = new RequestOptions({ headers: header }); 

      console.log("data:"+body);
      return this._client.post(url, body, options).pipe(map(resp => resp.json()));
}

}
