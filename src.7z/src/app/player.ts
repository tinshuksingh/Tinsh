export class Player {
    id: number;
    name: string;
  }