export class LoginDetail{
    email:String;
    password : String;
}