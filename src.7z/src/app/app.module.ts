import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { PlayersComponent } from './players/players.component';
import { PlayerDetailComponent } from './player-detail/player-detail.component';
import { MessagesComponent } from './messages/messages.component';
import { AppRoutingModule } from './/app-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';

import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { LocalStorage } from './local-storage';
import { LocalStorageService } from '../../node_modules/ng2-localstorage/dist';

@NgModule({
  declarations: [
    AppComponent,
    PlayersComponent,
    PlayerDetailComponent,
    MessagesComponent,
    DashboardComponent,
    LoginComponent,
    HeaderComponent,
    FooterComponent
   ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    HttpModule,
    ReactiveFormsModule
    
   // HttpClientInMemoryWebApiModule.forRoot(
     // InMemoryDataService, { dataEncapsulation: false }
    //)
  ],
  providers: [
    LocalStorage,
    LocalStorageService,
    LoginComponent,
    DashboardComponent,
    FooterComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
